import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAccount } from "wagmi";
import { Plus, ChevronRight, Clock, CheckCircle, XCircle, Zap, Wallet, AlertCircle, FileClock } from "lucide-react";
import { useTasks, useWebSocket } from "../hooks/useApi";
import type { WSEvent } from "../types";
import { useCallback } from "react";
import LiveFeed from "../components/dashboard/LiveFeed";
import TaskReplay from "../components/dashboard/TaskReplay";

export default function Dashboard() {
  const { address, isConnected } = useAccount();
  const { tasks, loadingMore, hasMore, loadMore, createTask, refresh } = useTasks(address);
  //const createTask = useCreateTask();
  const navigate = useNavigate();

  const loadMoreSentinelRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!hasMore) return;
    const el = loadMoreSentinelRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) loadMore();
      },
      { rootMargin: "200px" } // start loading a bit before it's actually visible
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [hasMore, loadMore]);

  const [description, setDescription] = useState("");
  const [budget, setBudget] = useState(5);
  const [submitting, setSubmitting] = useState(false);
  const [submitStep, setSubmitStep] = useState<"" | "approving" | "locking" | "confirming" | "registering">("");
  const [error, setError] = useState("");

  const [events, setEvents] = useState<Array<WSEvent & { id: string }>>([]);

  useWebSocket(
    useCallback(
      (event: WSEvent) => {
        if (!address) return;
        if (event.type === "task:created" || event.type === "task:updated") {
          refresh();
        }
        // Surface every event in the live feed, not just the two that
        // trigger a refresh — this is what shows agents actually working
        // (hiring, executing, submitting, getting paid) instead of a
        // black box that just says "processing."
        setEvents((prev) => [
          { ...event, id: `${event.type}-${event.timestamp}-${Math.random().toString(36).slice(2, 7)}` },
          ...prev,
        ].slice(0, 50));
      },
      [address, refresh]
    )
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isConnected || !address) {
      setError("Connect your wallet to submit a task");
      return;
    }
    if (!description.trim()) {
      setError("Please describe your task");
      return;
    }
    if (budget < 1) {
      setError("Minimum budget is 1 USDC");
      return;
    }

    setSubmitting(true);
    setSubmitStep("approving");
    setError("");

    try {
      const result = await createTask(
        {
          description: description.trim(),
          budget: Math.floor(budget * 1_000_000),
        },
        (step) => setSubmitStep(step)
      );
      navigate(`/tasks/${result.id}`);
    } catch (err: any) {
      setError(err.message || "Failed to create task");
    } finally {
      setSubmitting(false);
      setSubmitStep("");
    }
  };

  const recentTasks = tasks;

  return (
    <div style={{ maxWidth: 1100, margin: "0 auto" }}>
      {/* Hero */}
      <div style={{ marginBottom: 32 }}>
        <h1
          style={{
            fontFamily: "var(--font-display)",
            fontWeight: 800,
            fontSize: "1.8rem",
            letterSpacing: "-0.03em",
            marginBottom: 6,
          }}
        >
          Turn Any Idea Into a Working App
        </h1>
        <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>
          Specialized AI agents plan, build, and review real software — collaboratively, autonomously, and settled on-chain.
        </p>
      </div>

      {/* Stats */}
      <div className="stats-grid" style={{ marginBottom: 32 }}>
        <StatCard
          label="Total Tasks"
          value={tasks.length}
          icon={<Clock size={16} />}
          color="var(--arc)"
        />
        <StatCard
          label="Completed"
          value={tasks.filter((t) => t.status === "completed").length}
          icon={<CheckCircle size={16} />}
          color="var(--green)"
        />
        <StatCard
          label="In Progress"
          value={tasks.filter((t) => !["completed", "failed", "cancelled"].includes(t.status)).length}
          icon={<Zap size={16} />}
          color="var(--yellow)"
        />
        <StatCard
          label="Total Volume"
          value={`$${(tasks.reduce((s, t) => s + t.totalBudget, 0) / 1_000_000).toFixed(2)}`}
          icon={<Wallet size={16} />}
          color="var(--usdc)"
        />
      </div>

      <div className="dashboard-grid">
        {/* Recent Tasks */}
        <div>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 14,
            }}
          >
            <h2
              style={{
                fontWeight: 700,
                fontSize: "0.95rem",
                color: "var(--text-primary)",
              }}
            >
              Recent Tasks
            </h2>
            {tasks.length > 8 && (
              <span style={{ fontSize: "0.7rem", color: "var(--text-muted)", fontFamily: "var(--font-mono)" }}>
                Showing 8 of {tasks.length}
              </span>
            )}
          </div>

          {recentTasks.length === 0 ? (
            <div
              className="card"
              style={{
                textAlign: "center",
                padding: 48,
                color: "var(--text-muted)",
                fontSize: "0.85rem",
              }}
            >
              <FileClock size={32} color="var(--text-muted)" style={{ opacity: 0.6, marginBottom: 12 }} />
              <div>No tasks yet. Submit your first task to get started.</div>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {recentTasks.map((task) => (
                <TaskRow key={task.id} task={task} onClick={() => navigate(`/tasks/${task.id}`)} />
              ))}
            </div>
          )}

          {/* Infinite scroll: loading this sentinel into view fetches the
              next page of tasks automatically, instead of a numbered
              pager or fetching everything unbounded up front. */}
          {hasMore && (
            <div ref={loadMoreSentinelRef} style={{ padding: "16px 0", textAlign: "center" }}>
              <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>
                {loadingMore ? "Loading more..." : ""}
              </span>
            </div>
          )}
        </div>

        {/* Create Task Form */}
        <div>
          <div
            style={{
              fontWeight: 700,
              fontSize: "0.95rem",
              color: "var(--text-primary)",
              marginBottom: 14,
            }}
          >
            Submit New Task
          </div>
          <div className="card" style={{ padding: 20 }}>
            {!isConnected ? (
              // Wallet-gate up front: explain what's needed before the user
              // invests effort filling out a form they can't submit.
              <div style={{ textAlign: "center", padding: "16px 8px" }}>
                <Wallet size={22} color="var(--text-muted)" style={{ opacity: 0.6, marginBottom: 8 }} />
                <div style={{ fontSize: "0.82rem", color: "var(--text-secondary)" }}>
                  Connect your wallet to submit a task
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <div style={{ marginBottom: 16 }}>
                  <label htmlFor="task-description">Task Description</label>
                  <textarea
                    id="task-description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="e.g., Build a simple to-do list app using vanilla JavaScript and localStorage"
                    disabled={submitting}
                    style={{ fontSize: "0.85rem" }}
                  />
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 8 }}>
                    {[
                      "Build a simple to-do list app using vanilla JavaScript and localStorage",
                      "Build a Pomodoro timer web app with HTML, CSS, and JavaScript",
                      "Research the top 5 DeFi protocols on Arc blockchain",
                    ].map((example) => (
                      <button
                        key={example}
                        type="button"
                        onClick={() => setDescription(example)}
                        disabled={submitting}
                        style={{
                          fontSize: "0.68rem",
                          padding: "4px 10px",
                          borderRadius: 999,
                          border: "1px solid var(--border-bright)",
                          background: "var(--bg-hover)",
                          color: "var(--text-secondary)",
                          cursor: "pointer",
                        }}
                      >
                        {example.split(" ").slice(0, 5).join(" ")}...
                      </button>
                    ))}
                  </div>
                </div>

                <div style={{ marginBottom: 16 }}>
                  <label htmlFor="task-budget">Budget (USDC)</label>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <input
                      id="task-budget"
                      type="range"
                      min="1"
                      max="50"
                      step="1"
                      value={budget}
                      onChange={(e) => setBudget(Number(e.target.value))}
                      disabled={submitting}
                      style={{ flex: 1 }}
                    />
                    <span
                      className="badge badge-usdc"
                      style={{ fontSize: "0.85rem", padding: "6px 12px", minWidth: 70, textAlign: "center" }}
                    >
                      ${budget}
                    </span>
                  </div>
                  <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", marginTop: 6, fontFamily: "var(--font-mono)" }}>
                    Funds locked in escrow • Settled on Arc testnet
                  </div>
                </div>

                {error && (
                  <div
                    role="alert"
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 6,
                      padding: "8px 12px",
                      background: "var(--red-dim)",
                      border: "1px solid rgba(255,77,106,0.2)",
                      borderRadius: "var(--radius)",
                      color: "var(--red)",
                      fontSize: "0.78rem",
                      marginBottom: 12,
                    }}
                  >
                    <AlertCircle size={14} />
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  className="btn btn-primary btn-full-mobile"
                  disabled={submitting}
                  style={{ width: "100%", justifyContent: "center" }}
                >
                  {submitting ? (
                    <>
                      <span className="animate-spin">⟳</span>
                      {submitStep === "approving" && "Approving USDC in wallet…"}
                      {submitStep === "locking" && "Locking budget in escrow…"}
                      {submitStep === "confirming" && "Confirming on-chain…"}
                      {submitStep === "registering" && "Finalizing…"}
                      {!submitStep && "Submitting..."}
                    </>
                  ) : (
                    <>
                      <Plus size={16} /> Submit Task
                    </>
                  )}
                </button>
                <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", marginTop: 8, textAlign: "center" }}>
                  This will prompt your wallet {submitting ? "" : "up to twice "}— once to approve USDC, once to lock the budget in escrow.
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Live Activity — connected users see their own real-time feed;
            disconnected visitors see a replay of a real completed task
            instead of an empty "waiting for events" box */}
        <div style={{ marginTop: 24 }}>
          <div
            style={{
              fontWeight: 700,
              fontSize: "0.95rem",
              color: "var(--text-primary)",
              marginBottom: 14,
            }}
          >
            {isConnected ? "Live Activity" : "See It In Action"}
          </div>
          {isConnected ? <LiveFeed events={events} /> : <TaskReplay />}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon, color }: { label: string; value: any; icon: React.ReactNode; color: string }) {
  return (
    <div className="card" style={{ padding: "14px 16px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <div
          style={{
            width: 28,
            height: 28,
            borderRadius: 6,
            background: `${color}20`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color,
          }}
        >
          {icon}
        </div>
        <span style={{ fontSize: "0.7rem", color: "var(--text-muted)", fontFamily: "var(--font-mono)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
          {label}
        </span>
      </div>
      <div style={{ fontFamily: "var(--font-mono)", fontWeight: 700, fontSize: "1.4rem", color }}>{value}</div>
    </div>
  );
}

function TaskRow({ task, onClick }: { task: any; onClick: () => void }) {
  const statusConfig: Record<string, { badge: string; icon: React.ReactNode; label: string }> = {
    pending: { badge: "badge-muted", icon: <Clock size={10} />, label: "Pending" },
    decomposing: { badge: "badge-yellow", icon: <Zap size={10} />, label: "Decomposing" },
    assigning: { badge: "badge-arc", icon: <Zap size={10} />, label: "Assigning" },
    executing: { badge: "badge-arc", icon: <Zap size={10} />, label: "Executing" },
    evaluating: { badge: "badge-yellow", icon: <Clock size={10} />, label: "Evaluating" },
    completed: { badge: "badge-green", icon: <CheckCircle size={10} />, label: "Completed" },
    failed: { badge: "badge-red", icon: <XCircle size={10} />, label: "Failed" },
    cancelled: { badge: "badge-muted", icon: <XCircle size={10} />, label: "Cancelled" },
  };

  const cfg = statusConfig[task.status] || statusConfig.pending;
  const isActive = ["decomposing", "assigning", "executing", "evaluating"].includes(task.status);

  return (
    <div
      className="card animate-fade-in"
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onClick();
        }
      }}
      aria-label={`View task: ${task.description}`}
      style={{
        padding: "12px 16px",
        cursor: "pointer",
        borderColor: isActive ? "var(--arc)" : "var(--border)",
        transition: "all 0.15s",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
            <span className={`badge ${cfg.badge}`}>
              {isActive && <span style={{ animation: "spin 1s linear infinite", display: "inline-block" }}>⟳</span>}
              {cfg.icon}
              {cfg.label}
            </span>
            <span className="badge badge-usdc" style={{ fontSize: "0.65rem" }}>
              ${(task.totalBudget / 1_000_000).toFixed(2)}
            </span>
          </div>
          <p
            style={{
              fontSize: "0.8rem",
              color: "var(--text-secondary)",
              lineHeight: 1.4,
              overflow: "hidden",
              textOverflow: "ellipsis",
              display: "-webkit-box",
              WebkitLineClamp: 2,
              WebkitBoxOrient: "vertical",
            }}
          >
            {task.description}
          </p>
        </div>
        <ChevronRight size={16} color="var(--text-muted)" style={{ flexShrink: 0, marginTop: 4 }} aria-hidden="true" />
      </div>
    </div>
  );
}